import os, pathlib, json
assert pathlib.Path("answer.txt").read_text() == "42\n"
if os.environ["AUTODEV_ROLE"] in ("review", "audit"):
 d = dict(verdict="PASS", role=os.environ["AUTODEV_ROLE"], source_digest=os.environ["AUTODEV_SOURCE_DIGEST"], nonce=os.environ["AUTODEV_NONCE"], findings=[], checks=["isolated fixture equals 42; no organization acceptance claimed"])
 pathlib.Path(os.environ["AUTODEV_REPORT"]).write_text(json.dumps(d))
