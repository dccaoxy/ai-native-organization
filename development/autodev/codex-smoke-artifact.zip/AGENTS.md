This is an isolated synthetic adapter test. Only propose answer.txt containing exactly 42 followed by a newline. No external actions.
